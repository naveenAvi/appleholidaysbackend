<?php

namespace App\Http\Middleware;

use Illuminate\Foundation\Http\Middleware\VerifyCsrfToken as Middleware;

class VerifyCsrfToken extends Middleware
{
    /**
     * The URIs that should be excluded from CSRF verification.
     *
     * @var array
     */
    protected $except = [
        '/login-action',
        '/create-account-action',
        '/add-account-details',
        '/ads-details',
        '/ads-details-p',
        '/send-request-action',
        '/get-connected-users',
        '/get-message-history',
        '/accept-message',
        "/single-ads-details",
        "/get-contact-details",
        '/favourite-mark',
        '/get-payment-details'
    ];
}

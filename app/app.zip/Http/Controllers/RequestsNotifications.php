<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\StatsRequests;
use App\Models\RequestsModel;


class RequestsNotifications extends Controller
{
    public function isnewrequest($userid, $reuqiestid)
    {
        $StatsRequests = StatsRequests::where(['requestid'=>$requestid, "userid"=>$userid])->first();

        if( $StatsRequests ){
            return false;
        }else{
            return true;
        }
    }
    public static function UpdateUserview($userid, $viewedprofileuserid)
    {
        $RequestsModel = RequestsModel::where(["fromuserid"=>$userid, "touserid"=>$viewedprofileuserid])->first();
        if($RequestsModel){
            $RequestsModel->fromviewed = "1";
            $RequestsModel->save();
            
        }else{
            $RequestsModel = RequestsModel::where(["fromuserid"=>$viewedprofileuserid, "touserid"=>$userid ])->first();
            if($RequestsModel){
                $RequestsModel->toviewed = "1";
                $RequestsModel->save();
            }
        }
    }

    public function UpdateConnection($userid, $requestid)
    {
        $StatsRequests = StatsRequests::where(['requestid'=>$requestid, "userid"=>$userid])->delete();
    }

    public static function getUserViewStats($userid)
    {
        $recievedreq = RequestsModel::where([ "touserid"=>$userid, "status"=>"sent", "toviewed"=>"0"])->count();
        
        $confirmed = RequestsModel::where([ "touserid"=>$userid, "status"=>"confirm", "toviewed"=>"0" ])->count();
        $confirmed = $confirmed +  RequestsModel::where([ "fromuserid"=>$userid, "status"=>"confirmed", "fromviewed"=>"0"])->count();

        return array("recievedrequests"=>$recievedreq , "confirmedRequests"=>$confirmed );
    }
}

<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\UserModel;
use App\Models\UserDetailsModel;
use App\Models\FakeUsersModel;
use App\Models\SearchDataModel;
use App\Http\Controllers\TokenController;
use Illuminate\Support\Facades\Crypt;

class FakeUserSecond extends Controller
{
    public function getRandNumb($end){
        return mt_rand(0, $end-1);
    }
    public function generateEMail($firstName, $surname, $birthYear)
    {
        $vendores = ["gmail.com","Outlook.com","yandex.com"];
        $method = $this->getRandNumb(3);
        $emailAddress = "";
        if($method == 0){
            $emailAddress =  $firstName . $birthYear;
        }else if( $method == 1 ){
            $randSt = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
            $emailAddress =  $firstName . $randSt[$this->getRandNumb(strlen($randSt))] . $birthYear;
        }else if( $method == 2 ){
            $emailAddress =   $birthYear .$firstName;
        }else if( $method == 3 ){
            $emailAddress =   $birthYear .$randSt[$this->getRandNumb(strlen($randSt))] . $randSt[$this->getRandNumb(strlen($randSt))] . $randSt[$this->getRandNumb(strlen($randSt))] .$firstName;
        }
        return $emailAddress . "@" . $vendores[$this->getRandNumb(count($vendores))] ;
    }
    public function getDIstricts($userrace)
    {
        $SearchDataModel = new SearchDataModel();
        if( $userrace == "sinhala" ){
            return $SearchDataModel->DIstricts[$this->getRandNumb( count($SearchDataModel->DIstricts) )];
        }else{
            return $SearchDataModel->DIstrictsSInhala[$this->getRandNumb( count($SearchDataModel->DIstrictsSInhala) )];
        }
    }
    public function getSUrname($caste)
    {
        $surnames = ["Bandara", "Jayasinghe","Jayasooriya", "Ediriweera", "Edirimuni", "Kumara","Ranasinghe","Premarathne","Weerasinghe","Wikramasinghe","Rathnayaka","Wijesinghe","Wijerathne","Hettiarachchi","Nanayakkara", "Rajapaksha", "Amarasinghe","Samarasinghe","Senanayake","Basnayaka","Seneviratne","Jayawardena","Gunawardana"];
        $catholicSurnames = ["Perera","Fernando", "Peiris","Mendis", "Ekanayake","Dias","Amarasinghe","Samarasinghe","Senanayake", "Jayawardena","Fonseka","Alwis"];
        if( $caste == "sinhala" ){
            return $surnames[$this->getRandNumb(count($surnames))];
        }else if( $caste == "catholic" ){
            return $catholicSurnames[getRandNumb(count($catholicSurnames))];
        }
    }
    public function getUSerName($gender)
    {
        $selectedUSer = FakeUsersModel::inRandomOrder()->where(["gender"=>$gender])->first();
        return $selectedUSer->name;
    }
    public function CreateUser($gender)
    {
        $UserModel = new UserModel();
        $UserModel->username = "";
        $UserModel->firstname = $this->getUSerName($gender);
        $UserModel->secondname =  $this->getSUrname("sinhala");

        $UserModel->tel = "07712221";
        $UserModel->emailaddress =  $this->generateEMail( $UserModel->firstname, $UserModel->secondname, mt_rand(82, 92) );
        $UserModel->password = "defaultpass";
        $UserModel->isavail = "1";
        $UserModel->isb = "1";
        $UserModel->save();

        return array("userid"=>$UserModel->id , "username"=>$UserModel->firstname );
    }
    public function getBirthyearByName($name)
    {
        $Fakeuser = FakeUsersModel::where(["name"=>$name])->first();
        if( $Fakeuser ){
            if( $Fakeuser->newold == "new" ){
                return mt_rand(1988, 1995);
            }else{
                return mt_rand(1966, 1988);
            }
        }else{
            return mt_rand(1966, 1988);
        }
    }

    public function getProffessionThroughEducation($educationLevel, $gender)
    {
        if(( $educationLevel == "NoStudies" ) || ( $educationLevel == "beforeol" )){
            if( $gender == "male" ){
                $data = ["selfEmployee", "Farmer", "Cashier", "Driver", "Labour", "Chef"];
                return $data[$this->getRandNumb( count($data) )];
            }else{
                $data = ["Beautician", "Farmer", "Cashier", "at Home","Garment Worker"];
                return $data[$this->getRandNumb( count($data) )];
            }
        }else if( $educationLevel == "Ol" ){
            if( $gender == "male" ){
                $data = ["selfEmployee", "Farmer", "Cashier", "Driver", "Labour","Chef", "Technician"];
                return $data[$this->getRandNumb( count($data) )];
            }else{
                $data = ["No","No","No","No","No","No","No","Beautician", "Farmer", "Cashier", "at Home", "Garment Worker","designer"];
                return $data[$this->getRandNumb( count($data) )];
            }
        }else if( $educationLevel == "Al" ){


            if( $gender == "male" ){
                $data = ["selfEmployee", "Beautician", "Farmer", "Cashier", "Driver", "Labour","Government", "Teacher"];
                return $data[$this->getRandNumb( count($data) )];
            }else{
                $data = ["No","No","No","No","No","No","No","Beautician", "Farmer", "Cashier", "at Home", "Government", "Teacher"];
                return $data[$this->getRandNumb( count($data) )];
            }
        }else if( $educationLevel == "Diploma" ){
            if( $gender == "male" ){
                $data = ["selfEmployee", "Beautician", "Farmer", "Cashier", "Driver", "Labour","Government", "Teacher","ship-related"];
                return $data[$this->getRandNumb( count($data) )];
            }else{
                $data = ["No","No","No","Beautician", "Farmer", "Cashier", "at Home", "Government", "Teacher"];
                return $data[$this->getRandNumb( count($data) )];
            }
        }else if(( $educationLevel == "UnderGraduate")||( $educationLevel == "Bachelordegree")) {
            //even higher
            if( $gender == "male" ){
                $data = ["selfEmployee", "Accountant", "Manager", "Engineer","Government", "Teacher", "Businessman", "Analyst", "Developer", "designer","Doctor", "Specialist", "Executive","Technician","ship-related" ];
                return $data[$this->getRandNumb( count($data) )];
            }else{
                $data = [ "Accountant", "Manager", "Engineer","Government", "Teacher", "Businessman", "Analyst",  "designer","Doctor", "Specialist", "Executive" ];
                return $data[$this->getRandNumb( count($data) )];
            }
        }else{
            $data = ["Engineer","Government", "Analyst", "Doctor", "Specialist"];
            return $data[$this->getRandNumb( count($data) )];
        }
    }

    public function monthlysalery($proffession)
    {
        //["Accountant", "Manager", "Engineer", "Teacher", "Businessman", "Analyst", "Developer", "designer", "selfEmployee", "Farmer", "Doctor", "Specialist", "Executive", "Cashier", "Driver", "Beautician", "Chef", "Garment Worker", "Technician", "ship-related"];

        $saleriRanges = array("Accountant"=>["category4","category5"],
           "Manager"=>["category4","category5"],
           "Engineer"=>["category4","category5","category6","category7"],
           "Teacher"=>["category3","category4","category5"],
           "Businessman"=>["category4","category5","category6","category7","category8","category9","category10"],
           "Analyst"=>["category4","category5","category6"],
           "Developer"=>["category3","category4","category5","category6"],
           "designer"=>["category3","category4","category5","category6","category7"],
           "selfEmployee"=>["category2","category3","category4","category5"],
           "Farmer"=>["category2","category3","category4","category5","category6"],
           "Doctor"=>["category4","category5","category6","category7","category8","category9","category10"],
           "Specialist"=>["category4","category5","category6","category7","category8","category9","category10"],
           "Executive"=>["category4","category5","category6","category7"],
           "Cashier"=>["category3","category2","category4","category5"], 
           "Driver"=>["category3","category2","category4","category5"],
           "Beautician"=>["category4","category5","category6","category7","category8","category9","category10"],
           "Chef"=>["category4","category5","category6","category7"],
           "Garment Worker"=>["category2","category3","category4","category5","category6"],
           "Technician"=>["category3","category4"],
           "ship-related"=>["category4","category5","category6","category7","category8","category9","category10"],
           "Government"=>["category3","category4","category5"],
       );
        return $saleriRanges[$proffession][$this->getRandNumb( count($saleriRanges[$proffession]) )];


/*
        ["category3","category4","category5","category6","category7"]


        <option value={"unemployee"}>Rs: 0</option>
        <option value={"category1"}>Rs 0 - 14,999</option>
        <option value={"category2"}>Rs 15,000 - 49,999</option>
        <option value={"category3"}>Rs 50,000 - 79,999</option>
        <option value={"category4"}>Rs 80,000 - 99,999</option>
        <option value={"category5"}>Rs 100,000 - 149,999</option>
        <option value={"category6"}>Rs 150,000 - 199,999</option>
        <option value={"category7"}>Rs 200,000 - 299,999</option>
        <option value={"category8"}>Rs 300,000 - 399,999</option>
        <option value={"category9"}>Rs 400,000 - 499,999</option>
        <option value={"category10"}>Rs 500,000 or more</option>
        */
    }
public function GenerateDetails($catholicBuddist, $maleFemale, $marriedNone )
{

    $SearchDataModel = new SearchDataModel();
    if( $maleFemale== "female"){
        $maxeducation = $SearchDataModel->maxeducationFIltered;
    }else{
        $maxeducation = $SearchDataModel->maxeducation;
    }


    $DIstricts = $SearchDataModel->DIstricts;

    $raceList = $SearchDataModel->raceList ;

    $religionslist = $SearchDataModel->religionslist;


    $heightoptions = $SearchDataModel->heightoptionsFIltered;

    $kula = $SearchDataModel->kula;

    $months = $SearchDataModel->months;

    $drinking = $SearchDataModel->drinking;
    $simpleyesno = $SearchDataModel->simpleyesno;
$skincolors = $SearchDataModel->skincolors;



    $UserDetailsModel = new UserDetailsModel();
    $userdetails = $this->CreateUser($maleFemale);
        //array("userid"=>$UserModel->id , "username"=>$UserModel->firstname )
    $UserDetailsModel->userid = $userdetails["userid"];
    $UserDetailsModel->birthday = $this->getBirthyearByName($userdetails["username"]) . "-" . $months[$this->getRandNumb( count($months) )] . "-" . mt_rand(1, 30) ;
    $UserDetailsModel->height = $heightoptions[$this->getRandNumb( count($heightoptions) )];
    $UserDetailsModel->gender = $maleFemale;
    $UserDetailsModel->race = "Sinhala";

    $UserDetailsModel->religion = $catholicBuddist;
    $UserDetailsModel->caste = $kula[$this->getRandNumb( count($kula) )];
    $UserDetailsModel->civilstatus = $marriedNone;
    $UserDetailsModel->district = $this->getDIstricts("Sinhala");
    $educationLevel = $this->getRandNumb( count($maxeducation) );
    $UserDetailsModel->maxeducation = $maxeducation[$educationLevel];

        //getting most relevent proffesoin for education
    $proffessionDDD = $this->getProffessionThroughEducation( $maxeducation[$educationLevel], $maleFemale);

    $UserDetailsModel->proffession = $proffessionDDD;


    if($proffessionDDD == "No"){
        $UserDetailsModel->monthlyearnings = "unemployee";
    }else {
        $UserDetailsModel->monthlyearnings = $this->monthlysalery($proffessionDDD);
    }



    if($maleFemale == "female"){
        $UserDetailsModel->smoking = "No";
        $UserDetailsModel->drinking = "No";
    }else{
        $nonesmokers = "Accountant Manager Engineer Teacher Analyst Developer designer Doctor Specialist Executive Beautician";
        if( strpos($nonesmokers, $proffessionDDD) !== false){
            $UserDetailsModel->smoking = "No";
        }else{
            $UserDetailsModel->smoking = $simpleyesno[$this->getRandNumb( count($simpleyesno) )];
        }
        $UserDetailsModel->drinking = $drinking[$this->getRandNumb( count($drinking) )];
    }

    $UserDetailsModel->contactmethod = "email";

    $UserDetailsModel->email = "553";
    $UserDetailsModel->phone = "111";
    $UserDetailsModel->horoscopematching = $simpleyesno[$this->getRandNumb( count($simpleyesno) )];

    $UserDetailsModel->birthtime = "";



    $UserDetailsModel->properties = "";
    //using the same algorithm to get a depositesvalue
    $UserDetailsModel->deposits = $this->monthlysalery($proffessionDDD);
    $UserDetailsModel->skincolor = $skincolors[ $this->getRandNumb( count($skincolors) ) ];
    $UserDetailsModel->disorders = "";
    $UserDetailsModel->liketoleave = $simpleyesno[$this->getRandNumb( count($simpleyesno) )];


    $UserDetailsModel->isavail = "1";

    $UserDetailsModel->save();

    return "done";
}

public function GenerateUser()
{
    $religions = ["Buddist", "Buddist","Buddist","Catholic"];
    $Gender = ["male","male", "female","female","female","female"];
    $Marrynone = ["Married", "NoneMarried", "NoneMarried", "NoneMarried"];

    $selectedReligion = $religions[$this->getRandNumb( count($religions) )];
    $selectedGender = $Gender[$this->getRandNumb( count($Gender) )];
    $SelectedMarrynone = $Marrynone[$this->getRandNumb( count($Marrynone) )];
    $this->GenerateDetails($selectedReligion,$selectedGender,$SelectedMarrynone);
    return "done";
}

public function thousandusers()
{
    //userdetails email address "553"

    for ($i=0; $i < 1; $i++) { 
        $this->GenerateUser();
    }
    echo "generated";
}
}

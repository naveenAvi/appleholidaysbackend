<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\UserModel;
use App\Models\UserDetailsModel;
use App\Models\SearchDataModel;
use App\Models\RequestsModel;
use App\Models\ImagesModel;
use App\Http\Controllers\TokenController;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;


class ContactdetailsController extends Controller
{
    public static function getContactMethod($userid, $otherparticipantID, $viewingmode)
    {
        if( $userid !== "no"){
        //return image links as an array

            $RequestsModel = RequestsModel::where(function($query) use($otherparticipantID, $userid)
            {
                $query->where(["fromuserid"=>$otherparticipantID, "status"=>"confirmed", "touserid"=>$userid]);

            })
            ->orwhere(function($query) use($otherparticipantID, $userid)
            {
                $query->where(["touserid"=>$otherparticipantID,"status"=>"confirmed", "fromuserid"=>$userid]);

            })->first();
        }else{
            $RequestsModel = false;
        }
        if( $viewingmode == "private" ){
            //want to return empty image array if same profile watching and set to private
            $RequestsModel = false;
        }
        
        $contactmethod = array();
        if($RequestsModel){
            //we want to show advertiement contact details. 
            $UserDetailsModel = UserDetailsModel::where(["id"=>$RequestsModel->advertisementid ])->first();
            if( $UserDetailsModel ){
                $contactmethod = array("contactmethod"=> $UserDetailsModel->contactmethod, "phone"=>$UserDetailsModel->phone, "email"=>$UserDetailsModel->email );


                return $contactmethod;
            }
        }else if(( $userid == $otherparticipantID ) && ( $viewingmode == "public" )){
            $UserDetailsModel = UserDetailsModel::where(["userid"=>$userid ])->first();
            if( $UserDetailsModel ){
                $contactmethod = array("contactmethod"=> $UserDetailsModel->contactmethod, "phone"=>$UserDetailsModel->phone, "email"=>$UserDetailsModel->email );


                return $contactmethod;
            }
        }
        return $contactmethod;
    }
    public static function getSecondName($userid, $otherparticipantID, $viewingmode, $secondName)
    {
        if( $userid !== "no"){
        //return image links as an array
            $RequestsModel = RequestsModel::where(function($query) use($otherparticipantID, $userid)
            {
                $query->where(["fromuserid"=>$otherparticipantID, "status"=>"confirmed", "touserid"=>$userid]);

            })
            ->orwhere(function($query) use($otherparticipantID, $userid)
            {
                $query->where(["touserid"=>$otherparticipantID,"status"=>"confirmed", "fromuserid"=>$userid]);

            })->first();
        }else{
           return $secondName[0] . ".";
        }
        

        if(( $viewingmode == "private" ) && ($userid== $otherparticipantID)){
            //want to return empty image array if same profile watching and set to private
            return $secondName[0] . ".";
        }else if($userid== $otherparticipantID){
            return $secondName;
        }
        if( $RequestsModel ){
            return $secondName;
        }else{
return $secondName[0] . ".";
        }
    }
}

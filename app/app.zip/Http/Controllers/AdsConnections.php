<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\UserModel;
use App\Models\UserDetailsModel;
use App\Models\RequestsModel;
use App\Models\Favourites;
use App\Http\Controllers\TokenController;
use Illuminate\Support\Facades\Crypt;

class AdsConnections extends Controller
{
    public function SendRequest(Request $request)
    {
        if(( $request->userid ) && ( $request->logindetais )){
            if (!( TokenController::isTokenValid( $request->userid, $request->logindetais  ) )){
                return json_encode(array("status"=>200, "message"=>"failed","data_arr"=>"login_required"));
            }
        }else{
            return json_encode(array("status"=>200, "message"=>"failed","data_arr"=>"incomplete_request"));
        }
        $userid = Crypt::decryptString($request->userid);

        //is valid userdetailsmodel
        $UserDetailsModel = UserDetailsModel::where(["id"=>$request->viewingdetail])->first();
        
    

        $hasRequestsModel = RequestsModel::where(["fromuserid"=>$userid,"touserid"=> $UserDetailsModel->userid])->first();
        if($hasRequestsModel){
            if( $hasRequestsModel->status !== "cancelled" ){
                $hasRequestsModel->status = "cancelled";
                $hasRequestsModel->save();

                return json_encode(array("status"=>200, "message"=>"success","data_arr"=>"no"));
            }else{
                $hasRequestsModel->status = "sent";
                $hasRequestsModel->save();

                return json_encode(array("status"=>200, "message"=>"success","data_arr"=>"sent"));
            }
            
        }
        
        
        if($UserDetailsModel){
            $RequestsModel = new RequestsModel();
            $RequestsModel->fromuserid = $userid;
            $RequestsModel->touserid = $UserDetailsModel->userid;
            $RequestsModel->status = "sent";
            $RequestsModel->advertisementid = $request->viewingdetail;
            $RequestsModel->save();

            return json_encode(array("status"=>200, "message"=>"success","data_arr"=>"request_sent"));
        }else{
            return json_encode(array("status"=>200, "message"=>"failed","data_arr"=>"invalid_advertisment"));
        }
    }

    public function MakeFavourite(Request $request)
    {
        $userid = Crypt::decryptString($request->userid);
        $favouriteuserid = UserDetailsModel::where(["id"=>$request->viewingdetail])->first()->userid;
        $Favourites = Favourites::where(['userid'=> $userid, 'favouriteuserid'=> $favouriteuserid])->first();
        

        if( $Favourites ){
            Favourites::where(['userid'=> $userid, 'favouriteuserid'=> $favouriteuserid])->delete();
            return json_encode(array("status"=>200,  "message" => 'success', "favourite"=>"0"));
        }else{
            $Favourites = new Favourites();
            $Favourites->userid = $userid;
            $Favourites->favouriteuserid = $favouriteuserid;
            $Favourites->save();

            return json_encode(array("status"=>200, "message" => 'success', "favourite"=>"1"));
        }
    }


}
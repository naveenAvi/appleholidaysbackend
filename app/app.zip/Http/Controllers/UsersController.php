<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\UserModel;
use App\Models\UserDetailsModel;
use App\Http\Controllers\TokenController;
use App\Http\Controllers\ImagesController;
use Illuminate\Support\Facades\Crypt;

class UsersController extends Controller
{
    public function login(Request $request)
    {
       /*  if !( $request->password){
            return json_encode(array("status"=>200, "message"=>"failed","data_arr"=>"password_required"));
        }*/
        if( $request->usertp  ){
            $singleuser = UserModel::where(["tel"=> $request->usertp, "password"=>$request->password])->first();
        }else if( $request->email){
            $singleuser = UserModel::where(["emailaddress"=> $request->email, "password"=>$request->password])->first();
        }else{
            return json_encode(array("status"=>200, "message"=>"failed","data_arr"=>"incomplete_request"));
        }

        if (!( $singleuser )){
            if( $request->usertp  ){
                $singleuser = UserModel::where(["tel"=> $request->usertp, "password"=>$request->password])->first();
            }
            if (!( $singleuser )){
                if( $request->email  ){
                    $singleuser = UserModel::where(["tel"=> $request->usertp, "password"=>$request->password])->first();
                }
            }
        }

        if($singleuser){
            $tokensuccess = TokenController::getToken($singleuser->id );
            if( $tokensuccess ){
                $returning_arr =  array("username"=>$singleuser->firstname, "notifications"=>4, "recieved"=>10, "approved"=>4, "connected"=>5, "account_complete"=>true, "token"=>$tokensuccess, "userid"=>Crypt::encryptString($singleuser->id ));
                return json_encode(array("status"=>200, "message"=>"success","data_arr"=>$returning_arr));
            }else{
                return json_encode(array("status"=>200, "message"=>"failed","data_arr"=>"usernotfound"));
            }
            
        }else{
            return json_encode(array("status"=>200, "message"=>"failed","data_arr"=>"usernotfound"));
        }
    }

    public function CreateAccount(Request $request)
    {
        if( $this->checkemailtp($request->email, $request->usertp) == false){
            return json_encode(array("status"=>200, "message"=>"emailtpused","data_arr"=>"emailphonealreadyinuse"));
        }
        $UserModel = new UserModel();
        $UserModel->username = "";
        $UserModel->firstname = $request->firstname;
        $UserModel->secondname =  $request->secondname;

        if( $request->usertp){
            $UserModel->tel = $request->usertp;
            $UserModel->emailaddress =  "no";
        }else{
           /*$UserModel->emailaddress =  $request->email;
           $UserModel->tel = "";*/
           return json_encode(array("status"=>200, "message"=>"failed","data_arr"=>"tp_isneed"));
       }


       $UserModel->password = $request->password;
       $UserModel->isavail = "1";
       $UserModel->isb = "0";
       $UserModel->save();

       return json_encode(array("status"=>200, "message"=>"success","data_arr"=>"successfull"));
   }

   private function checkemailtp($email, $tpno){
    if($tpno){
        $usermodel = UserModel::where(["tel"=> $tpno])->first();

    }else{
        $usermodel = UserModel::where(["emailaddress"=> $email])->first();
    }
    if($usermodel){
        return false;
    }else{
        return true;
    }
}

public function addUserDetails(Request $request){
            //id    userid  birthday    height  gender  race    religion    caste   civilstatus district    maxeducation    proffession monthlyearnings smoking drinking    contactmethod   email   phone   horoscopematching   birthtime

    if(( $request->userid ) && ( $request->token )){
        if (!( TokenController::isTokenValid( $request->userid, $request->token  ) )){
            return json_encode(array("status"=>200, "message"=>"failed","data_arr"=>"login_required"));
        }
    }else{
        return json_encode(array("status"=>200, "message"=>"failed","data_arr"=>"incomplete_request"));
    }
    ImagesController::uploadImages(Crypt::decryptString($request->userid),$request->images );

    if( $request->userid  ){
        $UserDetailsModel = UserDetailsModel::where(["userid"=>Crypt::decryptString($request->userid) ])->first();
        if(!($UserDetailsModel) ){
            $UserDetailsModel = new UserDetailsModel();
        }
       
        $UserDetailsModel->userid = Crypt::decryptString($request->userid) ;
        $UserDetailsModel->birthday = $request->data['birthyear'] . "-" .  $request->data['birthmonth'] . "-" .  $request->data['birthday'];
        $UserDetailsModel->height = $request->data['height'];
        $UserDetailsModel->gender = $request->data['Gender'];
        $UserDetailsModel->race = $request->data['Race'];

        $UserDetailsModel->religion = $request->data['Religion'];
        $UserDetailsModel->caste = $request->data['caste'];
        $UserDetailsModel->civilstatus = $request->data['civilstatus'];
        $UserDetailsModel->district = $request->data['district'];
        $UserDetailsModel->maxeducation = $request->data['maxeducation'];
        $UserDetailsModel->proffession = $request->data['proffession'];
        $UserDetailsModel->monthlyearnings = $request->data['monthlyearnings'];
        $UserDetailsModel->smoking = $request->data['smoking'];
        $UserDetailsModel->drinking = $request->data['drinking'];
        $UserDetailsModel->contactmethod = $request->data['contactMethod'];


        $UserDetailsModel->properties = $request->data['deposits'];
        $UserDetailsModel->deposits = $request->data['properties'];
        $UserDetailsModel->skincolor = $request->data['skincolor'];
        $UserDetailsModel->disorders = $request->data['disorders'];
        $UserDetailsModel->liketoleave = $request->data['liketoleave'];
        if(  $request->data['nearestcity'] ){
            $UserDetailsModel->nearestcity=>$request->data['nearestcity'];
        }else{
            $UserDetailsModel->nearestcity=> "";
        }
        


        if( $request->data['contactMethod'] == "email"){
            $UserDetailsModel->email = $request->data['emailaddress'];
            $UserDetailsModel->phone = "-";
        }else{
            $UserDetailsModel->email = "-";
            $UserDetailsModel->phone = $request->data['phonenumb'];
        }


        $UserDetailsModel->horoscopematching = $request->data['horoscopematching'];
        if(( $request->data['BirthHourse'] ) && ( $request->data['BirthMinutes'] ) && ($request->data['BirthAMPM'])){
            $UserDetailsModel->birthtime = $request->data['BirthHourse'] . ":" . $request->data['BirthMinutes'] . ":" . $request->data['BirthAMPM'];
        }else{
            $UserDetailsModel->birthtime = "no-need";
        }
        $UserDetailsModel->isavail = "1";
        $UserDetailsModel->save();

        //saving images


        return json_encode(array("status"=>200, "message"=>"success","data_arr"=>"successfull"));
    }else{
        return json_encode(array("status"=>200, "message"=>"failed","data_arr"=>"incomplete_data"));
    }
}



}

<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\UserModel;
use App\Models\UserDetailsModel;
use App\Models\SearchDataModel;
use App\Models\RequestsModel;
use App\Models\IsUserVIewed;
use App\Models\Favourites;
use App\Http\Controllers\TokenController;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\ImagesController;
use App\Http\Controllers\ContactdetailsController;
use App\Http\Controllers\RequestsNotifications;

use App\Http\Controllers\StatusController;
use DateTime;
use time;

class PostsCOntroller extends Controller
{
    public function index()
    {
        return "Hello";
    }
    public function getAge($birthday)
    {
         $date = new DateTime($birthday);
         $now = new DateTime();
         $interval = $now->diff($date);
         return $interval->y;
    }
    public function getTimeUpdated($lastUpdated)
    {

        $datetime1 = \Carbon\Carbon::now()->toDateTimeString();//start time
        //echo $datetime1;
        $datetime1 = new DateTime($datetime1);
        $datetime2 = new DateTime($lastUpdated);//end time
        $interval = $datetime1->diff($datetime2);

        if($interval->format('%M') > 0){
            return $interval->format('%M') . " Months Ago";
        }else if($interval->format('%d') > 0){
            return $interval->format('%d') . " Days Ago";
        }else if($interval->format('%h') > 0){
            return $interval->format('%h') . " Hourse ago";
        }else if($interval->format('%i') > 0){
            return $interval->format('%i') . " Minutes ago";
        }
    }
    public function getData(Request $request)
    {

        $UserDetailsModel = $this->FIltration($request->Filters)->orderBy("created_at", "DESC")->skip(($request->pagenumber-1) * 10)->take(10)->get();

        $dataarr = array();
        if($request->userid){
            $userid = Crypt::decryptString($request->userid);
        }else{
            $userid = "0";
        }
        
        foreach ($UserDetailsModel as $SingleDetail) {

            $UserModel = UserModel::where(["id"=>$SingleDetail->userid ])->first();
            $ImagesArry = ImagesController::getImages($userid, $SingleDetail->userid, $request->viewtype );
            $ContactdetailsController = ContactdetailsController::getContactMethod($userid, $SingleDetail->userid, $request->viewtype);
            $secondName = ContactdetailsController::getSecondName($userid, $SingleDetail->userid, $request->viewtype, $UserModel->secondname);

            $IsUserVIewed = IsUserVIewed::where(['userid'=>$userid, "viewedadsid"=>$SingleDetail->id])->first();

            if( $IsUserVIewed ){
                $IsUserVIewed = "1";
            }else{
                $IsUserVIewed = "0";
            }

            $isFavourite = Favourites::where(['userid'=>$userid, 'favouriteuserid'=>$SingleDetail->userid])->first();
            if( $isFavourite ){
                $isFavourite = "1";
            }else{
                $isFavourite = "0";
            }

            $tempArr = array('adid' =>$SingleDetail->id , "firstName"=>$UserModel->firstname,"secondNameFirstLetter"=>$secondName, "birthday"=>$SingleDetail->birthday, "Height"=>$SingleDetail->height, "gender"=>$SingleDetail->gender, "race"=>$SingleDetail->race,"religion"=>$SingleDetail->religion, "civilState"=>$SingleDetail->civilstatus, "district"=>$SingleDetail->district, "proffession"=>$SingleDetail->proffession, "maxedu"=>$SingleDetail->maxeducation,"smoking"=>$SingleDetail->smoking, "drinking"=>$SingleDetail->drinking, "horoscopematching"=>$SingleDetail->horoscopematching, "age"=>$this->getAge( $SingleDetail->birthday ), "caste"=>$SingleDetail->caste,"monthlyearnings"=>$SingleDetail->monthlyearnings, "maxeducation"=>$SingleDetail->maxeducation, "requeststatus"=>$this->getCOnnectinbetween( $userid ,$SingleDetail->userid, $request->viewtype  ), "usersimages"=> $ImagesArry , "contactdetails"=>$ContactdetailsController, "timeago"=>$this->getTimeUpdated($SingleDetail->updated_at) , "isnew"=>$IsUserVIewed, 'isFavourite'=>$isFavourite);

            array_push($dataarr, $tempArr);
        }

        //getting rows count to set in react
        $UserDetailsModel = $this->FIltration($request->Filters)->count();

        $application_status = StatusController::Application_status( $userid );
        return json_encode(array("message"=>"success", "status"=>200, "pages_count"=> round($UserDetailsModel / 10, 0) , "data_arr"=> $dataarr, "postscount"=>$UserDetailsModel, "application_status"=> $application_status ));
    }

    public function getAdsData(Request $request)
    {
        $SingleDetail = $UserDetailsModel =  UserDetailsModel::where(["isavail"=>"1", "id"=>$request->viewingdetail])->first();

        if($request->userid){
            $userid = Crypt::decryptString($request->userid);
        }else{
            $userid = "no";
        }
        //checking is the requesting ads belong to the same user
        $sameprofileview = "none";
        if( $userid == $SingleDetail->userid ){
            if( $request->viewtype == "none" ){
                $sameprofileview = "private";
            }else{
                $sameprofileview = $request->viewtype;
            }
            
        }
        $application_status = StatusController::Application_status( $userid );
        if( $SingleDetail ){
            $UserModel = UserModel::where(["id"=>$SingleDetail->userid ])->first();

            $ImagesArry = ImagesController::getImages($userid, $SingleDetail->userid, $request->viewtype);
            $ContactdetailsController = ContactdetailsController::getContactMethod($userid, $SingleDetail->userid, $request->viewtype);
            $secondName = ContactdetailsController::getSecondName($userid, $SingleDetail->userid, $request->viewtype, $UserModel->secondname);

            //updating stats for dashboard views
            RequestsNotifications::UpdateUserview( $userid, $SingleDetail->userid );

            //updating stats for advertiements view
            $IsUserVIewed = IsUserVIewed::where(['userid'=>$userid, "viewedadsid"=>$SingleDetail->id])->first();

            if((!($IsUserVIewed) ) && ($userid !== "no")){
                $IsUserVIewed = new IsUserVIewed();
                $IsUserVIewed->userid = $userid;
                 $IsUserVIewed->viewedadsid = $SingleDetail->id; 
                 $IsUserVIewed->save();  
            }
            $isFavourite = Favourites::where(['userid'=>$userid, 'favouriteuserid'=>$SingleDetail->userid])->first();
            if( $isFavourite ){
                $isFavourite = "1";
            }else{
                $isFavourite = "0";
            }

            $tempArr = array('adid' =>$SingleDetail->id , "firstName"=>$UserModel->firstname,"secondNameFirstLetter"=>$secondName, "birthday"=>$SingleDetail->birthday, "Height"=>$SingleDetail->height, "gender"=>$SingleDetail->gender, "race"=>$SingleDetail->race,"religion"=>$SingleDetail->religion, "civilState"=>$SingleDetail->civilstatus, "district"=>$SingleDetail->district, "nearestcity"=>$SingleDetail->nearestcity, "proffession"=>$SingleDetail->proffession, "maxedu"=>$SingleDetail->maxeducation,"smoking"=>$SingleDetail->smoking, "drinking"=>$SingleDetail->drinking, "horoscopematching"=>$SingleDetail->horoscopematching, "age"=>$this->getAge( $SingleDetail->birthday ), "caste"=>$SingleDetail->caste,"monthlyearnings"=>$SingleDetail->monthlyearnings, "requeststatus"=>$this->getCOnnectinbetween( $userid ,$SingleDetail->userid , $request->viewtype ), "usersimages"=> $ImagesArry ,  "contactdetails"=>$ContactdetailsController , "timeago"=>$this->getTimeUpdated($SingleDetail->updated_at),"deposits"=>$SingleDetail->deposits,"properties"=>$SingleDetail->properties,"skincolor"=>$SingleDetail->skincolor,"disorders"=>$SingleDetail->disorders,"liketoleave"=>$SingleDetail->liketoleave,  'isFavourite'=>$isFavourite
);

            

            return json_encode(array("message"=>"success", "status"=>200,  "data_arr"=> $tempArr, "issameprofile" => $sameprofileview, "application_status"=> $application_status ));
        }else{
            return json_encode(array("message"=>"failed", "status"=>200, "data_arr"=> "advertisement_not_found", "issameprofile"=>$sameprofileview, "application_status"=> $application_status ));
        }
        
    }

    public function getCOnnectinbetween($userid, $otherparticipantid, $viewtype)
    {
        if(( $userid == $otherparticipantid) && ( $viewtype == "public" )){
            return "confirmed";
        }
        if( $userid == "0"){
            return "no";
        }
        $RequestsModel = RequestsModel::where(["fromuserid"=>$userid, "touserid"=>$otherparticipantid])->first();
        if($RequestsModel){
            if( $RequestsModel->status == "sent" ){
                return "sent";
            }else if( $RequestsModel->status == "confirmed" ){
                return "confirmed";
            }else{
                return "no";
            }
        }else{
            $RequestsModel = RequestsModel::where(["fromuserid"=>$otherparticipantid, "touserid"=>$userid])->first();
            if( $RequestsModel){
                if( $RequestsModel->status == "sent" ){
                    return "recieved";
                }else if( $RequestsModel->status == "confirmed" ){
                    return "confirmed";
                }else{
                    return "no";
                }
            }else{
                return "no";
            }
        }
    }

     public function getIsViewed($userid, $otherparticipantid)
    {
        if(( $userid == $otherparticipantid)){
            return "confirmed";
        }
        if( $userid == "0"){
            return "no";
        }
        $RequestsModel = RequestsModel::where(["fromuserid"=>$userid, "touserid"=>$otherparticipantid])->first();
        if($RequestsModel){
            return $RequestsModel->fromviewed;
        }else{
            $RequestsModel = RequestsModel::where(["fromuserid"=>$otherparticipantid, "touserid"=>$userid ])->first();
            if($RequestsModel){
                return $RequestsModel->toviewed;
            }
           return 0;
        }
    }
    public function getDataSentRecievedLike(Request $request)
    {
        /*$UserDetailsModel =  UserDetailsModel::where(["isavail"=>"1"])->get();
        $userid = Crypt::decryptString($request->userid);
        if($request->submenuSelected == "myads"){
            $UserDetailsModel =  UserDetailsModel::where(["isavail"=>"1", "userid"=>$userid ])->skip(($request->pagenumber-1) * 10)->take(10)->get();
        }else if($request->submenuSelected == "sentrequests"){
            $UserDetailsModel =  UserDetailsModel::join('requests', "details.userid", "=","requests.touserid")->select("details.*")->where("requests.fromuserid","=", $userid  )->where("requests.status","=","sent")->skip(($request->pagenumber-1) * 10)->take(10)->get();

        }else if($request->submenuSelected == "recievedrequests"){
            $UserDetailsModel =  UserDetailsModel::join('requests', "details.userid", "=","requests.fromuserid")->select("details.*")->where("requests.touserid","=", $userid  )->where("requests.status","=","sent")->skip(($request->pagenumber-1) * 10)->take(10)->get();


        }else if($request->submenuSelected == "confirmed"){
            $UserDetailsModel1 =  UserDetailsModel::leftjoin('requests', "details.userid", "=","requests.touserid")->select("details.*")->where("requests.fromuserid","=", $userid  )->where("requests.status","=","confirmed")->get();
            $UserDetailsModel2 =  UserDetailsModel::join('requests', "details.userid", "=","requests.fromuserid")->select("details.*")->where("requests.touserid","=", $userid  )->where("requests.status","=","confirmed")->skip(($request->pagenumber-1) * 10)->take(10)->get();
            $UserDetailsModel = $UserDetailsModel1->merge($UserDetailsModel2);
        }
*/
        $userid = Crypt::decryptString($request->userid);
        $UserDetailsModel =  UserDetailsModel::where(["isavail"=>"1", "userid"=>$userid ]);
        
        if($request->submenuSelected == "myads"){
            $UserDetailsModel =  UserDetailsModel::where(["isavail"=>"1", "userid"=>$userid ]);
        }else if($request->submenuSelected == "sentrequests"){
            $UserDetailsModel =  UserDetailsModel::join('requests', "details.userid", "=","requests.touserid")->select("details.*")->where("requests.fromuserid","=", $userid  )->where("requests.status","=","sent");

        }else if($request->submenuSelected == "recievedrequests"){
            $UserDetailsModel =  UserDetailsModel::join('requests', "details.userid", "=","requests.fromuserid")->select("details.*")->where("requests.touserid","=", $userid  )->where("requests.status","=","sent");


        }else if($request->submenuSelected == "confirmed"){
            $UserDetailsModel1 =  UserDetailsModel::leftjoin('requests', "details.userid", "=","requests.touserid")->select("details.*")->where("requests.fromuserid","=", $userid  )->where("requests.status","=","confirmed");
            $UserDetailsModel2 =  UserDetailsModel::join('requests', "details.userid", "=","requests.fromuserid")->select("details.*")->where("requests.touserid","=", $userid  )->where("requests.status","=","confirmed");
            $UserDetailsModel = $UserDetailsModel1->unionAll($UserDetailsModel2);
        }else if($request->submenuSelected == "saved"){
            $UserDetailsModel = UserDetailsModel::join('favourites', "details.userid", "=","favourites.favouriteuserid")->select("details.*")->where("favourites.userid","=", $userid  );
        }
        $pagescount = $UserDetailsModel->count();
        $UserDetailsModel = $UserDetailsModel->skip(($request->pagenumber-1) * 10)->take(10)->get();

        $dataarr = array();

        foreach ($UserDetailsModel as $SingleDetail) {

            $UserModel = UserModel::where(["id"=>$SingleDetail->userid ])->first();

            $secondName = ContactdetailsController::getSecondName($userid, $SingleDetail->userid, "private", $UserModel->secondname);

            $RequestsNotifiuser = $this->getIsViewed($userid, $SingleDetail->userid );
            $isFavourite = Favourites::where(['userid'=>$userid, 'favouriteuserid'=>$SingleDetail->userid])->first();
            if( $isFavourite ){
                $isFavourite = "1";
            }else{
                $isFavourite = "0";
            }

            $tempArr = array('adid' =>$SingleDetail->id , "firstName"=>$UserModel->firstname,"secondNameFirstLetter"=>$secondName, "birthday"=>$SingleDetail->birthday, "Height"=>$SingleDetail->height, "gender"=>$SingleDetail->gender, "race"=>$SingleDetail->race,"religion"=>$SingleDetail->religion, "civilState"=>$SingleDetail->civilstatus, "district"=>$SingleDetail->district, "proffession"=>$SingleDetail->proffession, "maxedu"=>$SingleDetail->maxeducation,"smoking"=>$SingleDetail->smoking, "drinking"=>$SingleDetail->drinking, "horoscopematching"=>$SingleDetail->horoscopematching, "age"=>"32", "caste"=>$SingleDetail->caste,"monthlyearnings"=>$SingleDetail->monthlyearnings, "requeststatus"=>$this->getCOnnectinbetween( $userid ,$SingleDetail->userid  , $request->viewtype) , 'isnew'=>$RequestsNotifiuser, 'isFavourite'=>$isFavourite  );

            array_push($dataarr, $tempArr);
        }
        $application_status = StatusController::Application_status( $userid );
        $RequestsNotifications = RequestsNotifications::getUserViewStats($userid);
        return json_encode(array("message"=>"success", "status"=>200, "pages_count"=>round($pagescount/10,0) , "data_arr"=> $dataarr, "application_status"=> $application_status, "notifications"=>$RequestsNotifications ));
    }
    public function getReleventColumnName($optionName, $SearchDataModel)
    {

        $maxeducation = $SearchDataModel->maxeducation;
        if( in_array($optionName, $maxeducation) ){
            return "maxeducation";
        }
        $DIstricts = $SearchDataModel->DIstricts;
        if( in_array($optionName, $DIstricts) ){
            return "district";
        }
        $raceList = $SearchDataModel->raceList ;
        if( in_array( $optionName,$raceList) ){
            return "race";
        }
        $religionslist = $SearchDataModel->religionslist;
        if( in_array($optionName, $religionslist)){
            return "found";
        }
        
        $heightoptions = $SearchDataModel->heightoptionsFIltered;
        if( in_array($optionName, $heightoptions) ){
            return "height";
        }
        $kula = $SearchDataModel->kula;
        if( in_array($optionName, $kula) ){
            return "caste";
        }

        if( in_array($optionName, ["NoneMarried", "married", "Seperated"]) ){
            return "civilstatus";
        }

        $drinking = $SearchDataModel->drinking;
        $simpleyesno = $SearchDataModel->simpleyesno;

        
        $profession = $SearchDataModel->profession;
        if( in_array($optionName, $profession) ){
            return "profession";
        }

        $drinkingSearching = $SearchDataModel->drinkingSearching;
        if( in_array($optionName, $drinkingSearching) ){
            return "drinkingSearching";
        }

        $simpleyesnoSearching = $SearchDataModel->simpleyesnoSearching;
        if( in_array($optionName, $simpleyesnoSearching) ){
            return "simpleyesnoSearching";
        }

    }
    public function FIltration($allFIlters)
    {
        //print_r($allFIlters);
        $SearchDataModel = new SearchDataModel();
        $profession = array();
        $kula = array();
        $religionslist = array();
        $raceList = array();
        $DIstricts = array();
        $maxeducation = array();
        $drinking = array();
        $smoking = array();
        $civilstatus = array();
        $caste = array();

        $searches = array();

        
        foreach ($allFIlters as $optionName => $option) {
            if( $option == 1 ){
                $colname = $this->getReleventColumnName($optionName, $SearchDataModel);
                if( $colname == "race" ){
                    array_push( $raceList, $optionName );
                    $searches["race"] = $raceList;
                }else if( $colname == "district" ){
                    array_push( $DIstricts, $optionName );
                    $searches["district"] = $DIstricts;
                }else if( $colname == "maxeducation" ){
                    array_push( $maxeducation, $optionName );
                    $searches["maxeducation"] = $maxeducation;
                }else if( $colname == "drinkingSearching" ){
                    array_push( $drinking, str_replace("drinking", "", $optionName) );
                    $searches["drinking"] = $drinking;
                }else if( $colname == "simpleyesnoSearching" ){
                    array_push( $smoking, str_replace("smoking", "", $optionName) );
                    $searches["smoking"] = $smoking;
                }else if( $colname == "civilstatus" ){
                    array_push( $civilstatus, str_replace("civilstatus", "", $optionName) );
                    $searches["civilstatus"] = $civilstatus;
                }else if( $colname == "caste" ){
                    array_push( $caste, str_replace("caste", "", $optionName) );
                    $searches["caste"] = $caste;
                }


            }
        }

        $UserDetailsModel =  UserDetailsModel::where(["isavail"=>"1"]);
        foreach ($searches as $columnName=> $value) {
            $UserDetailsModel->where(function ($query) use ($value,$columnName){
                for ($i=0; $i < count($value); $i++) { 
                    $singleCOndition = $value[$i];
                    $query->orWhere( $columnName,$singleCOndition );
                }
            }); 
        }
        foreach ($allFIlters as $optionName => $option) {
            if( $optionName == "agefrom"){
                if( $option !== "anyage" ){
                    $birthyear = date("Y", strtotime("-" . $option . " years" ));
                    $UserDetailsModel->where("birthday", "<", ($birthyear . "-01-01"));
                }
            }
            if( $optionName == "ageto"){
                if( $option !== "anyage" ){
                    $birthyear = date("Y", strtotime("-" . $option . " years" ));
                    //echo $birthyear;
                    $UserDetailsModel->where("birthday", ">", $birthyear . "-12-31");
                }
            }
            if(( $optionName == "male") ||( $optionName == "female") ) {
                if(( $optionName == "male" ) && ($option == true)){
                    $UserDetailsModel->where("gender", "=", "male");
                }else if(( $optionName == "female" )&& ($option == true)){
                    $UserDetailsModel->where("gender", "=", "female");
                }
            }
        }


       //print_r($UserDetailsModel->toSql());
        return $UserDetailsModel;
    }
}

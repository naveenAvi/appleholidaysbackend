<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Str;
use App\Models\TokensModel;
use Illuminate\Support\Facades\Crypt;

class TokenController extends Controller
{
    public static function createToken(){
        $randomSring =Str::random(30);
        return $randomSring;
    }
    public static function getToken($userid){
        $isvalidtoken = true;
        $tokengenerated = "";
        while ($isvalidtoken) {
            $token = static::createToken();
            $TokenModels = TokensModel::where(["token"=>$token])->first();

            if(!($TokenModels ) ){
                $tokengenerated = $token;
                $isvalidtoken = false;
            }
        }
        
        $TokenModels = new TokensModel();
        $TokenModels->token = $tokengenerated;
        $TokenModels->userid = $userid;
        $TokenModels->save();
        return $tokengenerated;
    }

    public static function isTokenValid($userid, $token)
    {
        $TokensModel = TokensModel::where(["userid"=> Crypt::decryptString($userid), "token"=>$token])->first();
        if( $TokensModel ){
            return true;
        }else{
            return false;
        }
    }
}

<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\UserModel;
use App\Models\UserDetailsModel;
use App\Models\Payments;
use App\Http\Controllers\TokenController;
use App\Http\Controllers\ImagesController;
use Illuminate\Support\Facades\Crypt;

class StatusController extends Controller
{
    //this will validate and return data to determine application status and others
    public static function Application_status($userid)
    {
        if( $userid == "0"){
            return "not_registered";
        }
        $UserDetailsModel = UserDetailsModel::where(["userid"=>$userid])->first();

        if(!( $UserDetailsModel )){
            //he hasn't filled the application
            return "application_not_complete";
        }else{
            //getting the latest payment details
            $Payments = Payments::where(["userid"=>$userid])->orderBy('created_at', 'asc')->first();

            if( $Payments ){
                $validtill = date('Y-m-d', strtotime('+90 day', strtotime($Payments->created_at) ));
                $todaydate = date("Y-m-d");
                if( $validtill >= $todaydate  ){
                    return $validtill;
                }else{
                    return "expired";
                }
            }else{
                //he is not paid 
                return "should_pay";
            }
        }
    }
    public function userPaymentDetails(Request $request)
    {
        //checking valid token and userid
        //checking is he paid or not already
        //if not, getting the adsid as reference
        $userid = Crypt::decryptString($request->userid);
        $UserDetailsModel = UserDetailsModel::where(["userid"=> $userid])->first();
        if( $UserDetailsModel ){
            $Payments = Payments::where(["userid"=>$userid])->orderBy('created_at', 'asc')->first();
            if( $Payments ){
                //already paid
                //check if payments are valid
                $validtill = date('Y-m-d', strtotime('+90 day', $Payments->created_at ));
                $todaydate = ate("Y-m-d");
                if( $validtill >= $todaydate  ){
                    return json_encode(array("status"=>200, "paymentstatus"=> "valid", "referencenum"=>$UserDetailsModel->id));
                }else{
                    return json_encode(array("status"=>200, "paymentstatus"=> "expired", "referencenum"=>$UserDetailsModel->id));
                }
            }else{
                //never paid
                //he will recieve his ads id as reference number
                return json_encode(array("status"=>200, "paymentstatus"=> "never_paid", "referencenum"=>$UserDetailsModel->id));
            }
        }else{
            //he didn't completed the application
            return json_encode(array("status"=>200, "paymentstatus"=> "fill_application", "referencenum"=>$UserDetailsModel->id));
        }
    }
}

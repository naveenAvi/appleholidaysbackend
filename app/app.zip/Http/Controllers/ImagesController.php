<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\UserModel;
use App\Models\UserDetailsModel;
use App\Models\SearchDataModel;
use App\Models\RequestsModel;
use App\Models\ImagesModel;
use App\Http\Controllers\TokenController;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Image;

class ImagesController extends Controller
{

    public static function getImageMimeType($imagedata)
    {
      $imagemimetypes = array( 
        "jpeg" => "FFD8", 
        "png" => "89504E470D0A1A0A", 
        "gif" => "474946",
        "bmp" => "424D", 
        "tiff" => "4949",
        "tiff" => "4D4D"
    );

      foreach ($imagemimetypes as $mime => $hexbytes)
      {
        $firsthalf = explode( ";base64", $imagedata)[0];
        if( strpos( $firsthalf , $mime ) !== false ){
            return $mime;
        }
    }
    return null;
}
public static function generatefilename()
{
    $isaunique = true;
    $filename = "";
    while ($isaunique) {
        $simple = self::generateRandomString(10);
        $ImagesModel = ImagesModel::where("imageurl", "like", "%" . $simple . "%")->first();
        if( $ImagesModel ){
            
        }else{
            $isaunique = false;
            $filename = $simple;
        }
    }
    return $filename;
}
public static function uploadImages($userid, $imagearray)
{
    $mimetype = "";
    
    foreach ($imagearray as $Imagereference=>$imageData) {
            //echo $imageData;
        if(( $imageData !== "" )&& ($imageData !== "profile.png")){
            
            $ext =  self::getImageMimeType( $imageData );
            if( $ext !== null ){
                $ImagesModel = ImagesModel::where(["imagereference"=>$Imagereference, "userid"=>$userid])->get();
                foreach ($ImagesModel as $singleImage) {
                    self::deleteFile( $singleImage->imageurl );
                }
                $ImagesModel = ImagesModel::where(["imagereference"=>$Imagereference, "userid"=>$userid])->delete();
                //echo $imageData;
                $data = substr($imageData, strpos($imageData, ',') + 1);

                $resized_image = base64_decode($data);


                //resizing and adding water marks
                if( str_contains($Imagereference, "profileimage") !== false ){
                    $resized_image = Image::make($data)->resize(506, 612);
                    $watermark = Image::make('images/whiteLogo.png');

                    $resized_image->insert($watermark, 'center');

                    $resized_image = (string) $resized_image->encode();
                }
                

                $filename = self::generatefilename() . "." . $ext;
                Storage::disk('private')->put($filename , $resized_image );
                

                $ImagesModel = new ImagesModel();
                $ImagesModel->imageurl = $filename;
                $ImagesModel->userid = $userid;
                $ImagesModel->imagereference = $Imagereference;
                $ImagesModel->save();
            }
            
        }
    }

}
public function getProfileImage(Request $request)
{
        //check user token also

    $ImagesModel = ImagesModel::where(["userid"=>$userid])->get();
    $hasImages = true;
    $profileimage = "";
    foreach ($ImagesModel as $singleImage) {
        if(( strpos("profile", $singleImage->imagereference) !== false ) && ( $profileimage !== "" )){
            $profileimage = "http://127.0.0.1:8000/images/get/private/" . crypt::encryptString($singleImage->id);
        }
    }

    return json_encode(array("status"=>200, "message"=>"success","data_arr"=>$profileimage ));
}
public static function getImages($userid, $otherparticipantID, $viewingmode)
{


    if( $userid !== "no"){
        //return image links as an array
        $RequestsModel = RequestsModel::where(function($query) use($otherparticipantID, $userid)
        {
            $query->where(["fromuserid"=>$otherparticipantID, "status"=>"confirmed", "touserid"=>$userid]);

        })
        ->orwhere(function($query) use($otherparticipantID, $userid)
        {
            $query->where(["touserid"=>$otherparticipantID,"status"=>"confirmed", "fromuserid"=>$userid]);

        })->first();
    }else{
        $RequestsModel = false;
    }

    $imagesArr = array();
    if( ($RequestsModel) || (( $userid == $otherparticipantID ) && ( $viewingmode == "public" ) ) ){
            //can return images array. has permissions
        $ImagesModel = ImagesModel::where(["userid"=>$otherparticipantID])->get();
        $hasImages = true;
        foreach ($ImagesModel as $singleImage) {
            $imagesArr[ $singleImage->imagereference ] = "http://127.0.0.1:8000/images/get/private/" . crypt::encryptString($singleImage->id);
            $hasImages = false;
        }
        if($hasImages){
            $imagesArr["profilepic1"] = "";
            $imagesArr["profilepic2"] = "";
            $imagesArr["profilepic3"] = "";
            $imagesArr["profilepic4"] = "";

            $imagesArr["horoscopeimage1"] = "";
            $imagesArr["horoscopeimage2"] = "";
        }

    }else{
        $imagesArr["profilepic1"] = "";
        $imagesArr["profilepic2"] = "";
        $imagesArr["profilepic3"] = "";
        $imagesArr["profilepic4"] = "";

        $imagesArr["horoscopeimage1"] = "";
        $imagesArr["horoscopeimage2"] = "";
    }
    return $imagesArr;
}
public function getprivateimage(Request $request, $imageurl,$token, $userid )
{

        //check token 
    $isvalidtoken = TokenController::isTokenValid($userid, $token);

    if (!( $isvalidtoken )){
        abort(404);
    }


        //check user token

        //generate random string to make image id



        ///images/get/private/{imageurl}/{token}/{userid}
    $ImagesModel = ImagesModel::where(["id"=>Crypt::decryptString($imageurl)])->first();
    $userid = Crypt::decryptString($userid);
    if($ImagesModel){
        $RequestsModel = RequestsModel::where(["fromuserid"=>$ImagesModel->userid, "status"=>"confirmed", "touserid"=>$userid])->orwhere(["touserid"=>$ImagesModel->userid, "status"=>"confirmed", "fromuserid"=>$userid])->first();
        if($RequestsModel){
                //he has access to images
            $path = "/private/images-of-users/" . $ImagesModel->imageurl;
            if( Storage::exists($path) ){
                return Storage::download($path);
            }else{
                    //return a user image
                echo "Image not found";
            }
        }else{
            echo "has no access";
                //he dont have access
                //abort(404);
        }
    }else{
        echo "image not found";
            //abort(404);
    }

    $path = "/private/images-of-users/" . $request->imageurl;
    if( Storage::exists($path) ){
        return Storage::download($path);
    }
    abort(404);
}
public static function generateRandomString($length = 10) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}

public static function deleteFile($imagename)
{  
  if(Storage::exists("/private/images-of-users/" . $imagename)){
    Storage::delete("/private/images-of-users/" . $imagename);
  }else{
    return true;
  }
} 
}

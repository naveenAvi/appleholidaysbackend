<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\UserModel;
use App\Models\UserDetailsModel;
use App\Models\SearchDataModel;
use App\Models\RequestsModel;
use App\Models\MessagesModel;
use App\Http\Controllers\TokenController;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\DB;

class MessageCOntroller extends Controller
{
    public function sortCOllection($COllection)
    {
        $COllection = $COllection->sort("touserid");
        return $COllection;
        $COllection = $COllection->sort(function ($a, $b) {
            if($a->touserid > $b->touserid){
                return $a->touserid;
            }else{
                return $b->touserid;
            }
        });
        //"asort(): Argument #2 ($flags) must be of type int, string given"

       /* $COllection = $COllection->sortBy(function($value, $key) {
            return  $value['touserid'];
        });
        return $COllection;*/
/*
"first: {"id":1,"fromuserid":1,"touserid":14,"status":"confirm","advertisementid":27}
second: {"id":2,"fromuserid":1,"touserid":18,"status":"confirm","advertisementid":31}
first: {"id":2,"fromuserid":1,"touserid":18,"status":"confirm","advertisementid":31}
second: {"id":3,"fromuserid":1,"touserid":15,"status":"confirm","advertisementid":28}"

*/


        /*function build_sorter($COllection) {
            return function ($a, $b) use ($COllection) {
                echo $a, $b;
            };
        }

        usort($COllection, build_sorter($COllection));*/

        
        /*for ($i=1; $i < count($COllection) ; $i++) { 
            $singleRequest = $COllection[$i];
            $MessagesModel1 =  MessagesModel::orwhere("touser", "=", $singleRequest->fromuserid)->orwhere("fromuser","=", $singleRequest->fromuserid)->orderBy("id","DESC")->first();
            
            $MessagesModel2 =  MessagesModel::where("touser", "=", $singleRequest->touserid)->orwhere("fromuser","=", $singleRequest->touserid)->orderBy("id","DESC")->first();
            if(( $MessagesModel1 ) && ($MessagesModel2)){
                if($MessagesModel1->id > $MessagesModel2->id){
                    $aar[$singleRequest->fromuserid] = $MessagesModel1->id;
                }else{
                    $aar[$singleRequest->fromuserid] = $MessagesModel2->id;
                }
            }else if($MessagesModel1){
                $aar[$singleRequest->fromuserid] = $MessagesModel1->id;
            }else if($MessagesModel2){
                $aar[$singleRequest->touserid] = $MessagesModel2->id;
            }
        }*/
    }
    public function getCOnnectedUsers(Request $request)
    {
       if(( $request->userid ) && ( $request->token )){
        if (!( TokenController::isTokenValid( $request->userid, $request->token  ) )){
            return json_encode(array("status"=>200, "message"=>"failed","data_arr"=>"login_required"));
        }
    }else{
        return json_encode(array("status"=>200, "message"=>"failed","data_arr"=>"incomplete_request"));
    }

        /*$RequestsModel = RequestsModel::where("requests.status","=","confirmed")->orwhere(["requests.fromuserid"=>Crypt::decryptString($request->userid)])->get();
        $connectedUsers = array();
        foreach ($RequestsModel as $singleRequest) {
            $UserModel = UserModel::where(["id"=>$singleRequest->touserid])->first();
            $temparr = array("userid"=>$UserModel->id, "firstname"=>$UserModel->firstname, "secondname"=>$UserModel->secondname, "profileImage"=>"" );
            array_push($connectedUsers, $temparr);
        }
*/
        $RequestsModel = RequestsModel::where("status","=","confirmed")->where(["fromuserid"=>Crypt::decryptString($request->userid)])->get();
        return $this->sortCOllection($RequestsModel);



        $connectedUsers = array();
        foreach ($RequestsModel as $singleRequest) {
            $UserModel = UserModel::where(["id"=>$singleRequest->touserid])->first();
            $temparr = array("userid"=>$UserModel->id, "firstname"=>$UserModel->firstname, "secondname"=>$UserModel->secondname, "profileImage"=>"" );
            array_push($connectedUsers, $temparr);
        }



        $RequestsModel = RequestsModel::where("status","=","confirmed")->orwhere(["touserid"=>Crypt::decryptString($request->userid)])->get();
        $connectedusers = array();
        foreach ($RequestsModel as $singleRequest) {
            $UserModel = UserModel::where(["id"=>$singleRequest->fromuserid])->first();
            $temparr = array("userid"=>$UserModel->id, "firstname"=>$UserModel->firstname, "secondname"=>$UserModel->secondname , "profileImage"=>"");
            array_push($connectedUsers, $temparr);
        }
        return json_encode(array("message"=>"success", "data_arr"=>$connectedUsers));
    }

    public function returnMessages(Request $request)
    {
        $MessagesModel = MessagesModel::where(["fromuser"=>$request->userid])->orWhere(["touser"=>$request->userid])->orWhere(["fromuser"=>$request->otherparticipant])->orWhere(["touser"=>$request->otherparticipant])->get();
        return json_encode(array("message"=>"success", "data_arr"=>$MessagesModel));
    }

    public function acceptMessage(Request $request)
    {
        $MessagesModel = new MessagesModel();
        $MessagesModel->fromuser =Crypt::decryptString($request->userid);
        $MessagesModel->touser = $request->otherparticipant;
        $MessagesModel->message = $request->message;
        $MessagesModel->save();
        return json_encode(array("message"=>"success", "data_arr"=>$MessagesModel));
    }
}

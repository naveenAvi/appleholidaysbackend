<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class StatsRequests extends Model
{
    protected $table = 'stats_requestsview';

   public $timestamps = false;

   protected $fillable = [
        'id',  'userid',  'requestid'   

    ];
}

<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class MessagesModel extends Model
{
    protected $table = 'messages';

   public $timestamps = false;

   protected $fillable = [
        'id','fromuser','touser','message' 
    ];
}

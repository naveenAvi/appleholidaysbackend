<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Favourites extends Model
{
    protected $table = 'favourites';

   public $timestamps = false;

   protected $fillable = [
            'id',  'userid',  'favouriteuserid' ,'created_at'  

    ];
}

<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SearchDataModel extends Model
{
    public $maxeducationFIltered = ["NoStudies", "beforeol", "Ol",  "Al", "UnderGraduate", "Diploma", "Al", "Diploma","Al", "Diploma", "UnderGraduate", "Bachelordegree"];

    public  $maxeducation = ["NoStudies", "beforeol", "Ol", "Al","UnderGraduate", "Diploma",  "Bachelordegree", "MasterDegree", "PhdDoctorial"];

    public $DIstricts = ["Ampara", "anuradhapura", "Badulla", "Batticaloa", "Colombo", "Galle","Gampaha", "Kaluthara","Hambanthota","Jaffna","Kaluthara","Kegalle", "Kilinochchi","Kurunegala",'Mannar', "Kandy","Matale","Matara","Moneragala","Mullativu","NuwaraEliya","Polonnaruwa","Puttalam","Ratnapura","Trincomalee",'Vavuniya'];
    public $DIstrictsSInhala = [ "anuradhapura", "Badulla",  "Colombo", "Galle","Gampaha","Hambanthota","Kaluthara","Kegalle", "Kurunegala",'Mannar',"Matale","Matara","Moneragala","NuwaraEliya","Polonnaruwa","Puttalam","Ratnapura","Trincomalee",'Vavuniya',"Kandy"];

    public $raceList = ['Sinhala', 'Tamil', 'Muslim', 'other'];

    public $religionslist = ['Buddist', 'Catholic', 'Christian', 'Hindu', "Islam", "Other"];


    public  $heightoptionsFIltered = ['5` 0"','5` 1"','5` 2"','5` 3"','5` 4"','5` 5"','5` 6"','5` 7"','5` 8"','5` 9"','5` 10"','5` 11"','6` 0"','6` 1"'];

    public  $kula = ['NoNeed','Radala','Govigama','Bathgama','Deva','Nekathi','Bodhivansa','Rajaka','Kumbal','Hunu','Durava','Karava','Salagama','Navandanna'];

    public  $months = ["january", "february", "march", "april", "may", "june", "july", "august", "september", "october", "november", "december"];

    public  $drinking = ['Yes',"No","Occassionaly"];
    public  $simpleyesno = ['Yes',"No"];

    public  $drinkingSearching = ['drinkingYes',"drinkingNo","drinkingOccassionaly"];
    public  $simpleyesnoSearching = ['smokingYes',"smokingNo"];

    public  $professionFemale = ["No","Accountant", "Manager", "Engineer", "Teacher", "HouseWife", "Analyst",  "designer", "selfEmployee"];

    public  $professionEducated = ["Accountant", "Manager", "Engineer", "Teacher", "Businessman", "Analyst", "Developer", "designer", "selfEmployee"];

    public  $profession = ["Accountant", "Manager", "Engineer", "Teacher", "Businessman", "Analyst", "Developer", "designer", "selfEmployee", "Farmer", "Doctor", "Specialist", "Executive", "Cashier", "Driver", "Beautician", "Chef", "Garment Worker", "Technician","ship-related"];


    public $skincolors =  ["Fair","lightbrown", "darkbrown", "black"];
}
 
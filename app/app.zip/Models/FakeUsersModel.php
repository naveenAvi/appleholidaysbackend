<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class FakeUsersModel extends Model
{
   protected $table = 'tempnames';

   public $timestamps = false;

   protected $fillable = [
        'name' ,   
'race'    ,
'religion'   , 
'gender' ,
"newold" 
    ];
}

<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class UserDetailsModel extends Model
{
     protected $table = 'details';

   public $timestamps = true;

   protected $fillable = [
        'id' , 'userid' , 'birthday'  ,  'height',  'gender'  ,'race',    'religion' ,   'caste'  , 'civilstatus', 'district', "nearestcity",   'maxeducation' ,   'proffession', 'monthlyearnings' ,'smoking', 'drinking' ,   'contactmethod',   'email'  , 'phone' ,  'horoscopematching' ,  'birthtime' ,'isavail', "created_at","updated_at", "properties", "deposits", "skincolor", "disorders", "liketoleave"
  
    ];
}



  
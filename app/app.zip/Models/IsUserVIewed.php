<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class IsUserVIewed extends Model
{
    
     protected $table = 'is_user_viewed';

   public $timestamps = false;

   protected $fillable = [
        'id',  'userid' , 'viewedadsid', 'created_at'  


    ];
}

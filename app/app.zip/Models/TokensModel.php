<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class TokensModel extends Model
{
     protected $table = 'tokens';

   public $timestamps = false;

   protected $fillable = [
        'id',  'token',   'userid',  'created_at'  

  
    ];
}



  